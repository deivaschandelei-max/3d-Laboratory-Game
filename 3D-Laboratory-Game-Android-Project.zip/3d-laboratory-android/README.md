# 3D Laboratory Game — Android project

Landscape Android wrapper for the existing Three.js lab prototype, with a GitHub Actions workflow that builds a debug APK and uploads it as an artifact.

## Build on GitHub
1. Upload all files and folders in this project to the root of your repository.
2. Open the repository's **Actions** tab.
3. Select **Build 3D Laboratory Game APK** and press **Run workflow** (or push to `main`).
4. When it finishes, open the run and download **3D-Laboratory-Game-APK** under Artifacts.

The WebView game uses Three.js from its CDN, so an internet connection is needed for the 3D library to load.
